create view inout_statistics as
select `drug`.`drug`.`drugName`    AS `drugName`,
       `drug`.`inaout`.`inNumber`  AS `inNumber`,
       `drug`.`inaout`.`outNumber` AS `outNumber`,
       `drug`.`drug`.`number`      AS `number`
from (`drug`.`drug`
         join `drug`.`inaout`)
where (`drug`.`drug`.`drugId` = `drug`.`inaout`.`drugId`);

