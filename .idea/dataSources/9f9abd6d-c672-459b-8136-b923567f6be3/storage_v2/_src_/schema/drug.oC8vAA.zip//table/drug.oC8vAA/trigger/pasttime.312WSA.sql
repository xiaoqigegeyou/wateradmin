create definer = root@localhost trigger pastTime
    before update
    on drug
    for each row
    set new.pastTime = DATE_ADD(new.proTime,INTERVAL new.shelfLife MONTH);

