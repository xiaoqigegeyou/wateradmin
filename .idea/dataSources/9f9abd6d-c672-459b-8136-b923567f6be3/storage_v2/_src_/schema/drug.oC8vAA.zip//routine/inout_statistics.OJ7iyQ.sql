create
    definer = root@localhost procedure inout_statistics()
BEGIN
	#Routine body goes here...
SELECT drug.drugId,drug.drugName,inAout.inNumber,inAout.outNumber
from inAout,drug
where drug.drugId = inAout.drugId;
END;

