create view 概览 as
select `my`.`order_tickect`.`fly_name`     AS `fly_name`,
       `my`.`order_tickect`.`takeoff_time` AS `takeoff_time`,
       `my`.`order_tickect`.`land_time`    AS `land_time`,
       `my`.`order_tickect`.`start_place`  AS `start_place`,
       `my`.`order_tickect`.`end_place`    AS `end_place`,
       `my`.`order_tickect`.`tickect_type` AS `tickect_type`,
       `my`.`order_tickect`.`price`        AS `price`,
       `my`.`order_tickect`.`name`         AS `name`,
       `my`.`order_tickect`.`id`           AS `id`
from `my`.`order_tickect`;

-- comment on column 概览.fly_name not supported: 航班号

-- comment on column 概览.tickect_type not supported: 购票类型

-- comment on column 概览.id not supported: 订单编号

