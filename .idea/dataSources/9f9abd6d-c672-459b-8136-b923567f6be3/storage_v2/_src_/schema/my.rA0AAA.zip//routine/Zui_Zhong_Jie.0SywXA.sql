create
    definer = root@localhost procedure 最终价(IN na decimal, OUT ee decimal)
BEGIN
	
	DECLARE ee DECIMAL(8,2); 
  select price,discount from  flight where fly_name=na;
	set @ee = price*(1-discount/100) ;


END;

